<#
.SYNOPSIS
    Live "window replica" viewer using the native Windows DWM Thumbnail API.
    No installer, no external binaries, no internet access required.

.DESCRIPTION
    Creates a small always-on-top window that shows a real-time, DWM-composited
    thumbnail of another window on the same machine (e.g. a KYC form running on
    a customer tablet's extended display). This calls the same underlying OS API
    (dwmapi.dll -> DwmRegisterThumbnail) that third-party tools like OnTopReplica
    use internally, but as a script your team can fully read and audit.

    Everything runs locally: Add-Type compiles a small C# interop shim using the
    .NET Framework compiler already present on Windows. No files are downloaded,
    no network calls are made, and nothing is installed.

.PARAMETER WindowTitle
    Wildcard match against the target window's title. Defaults to
    "*Self KYC Form*" -- so running the script with no arguments targets that
    window directly. If no match is found (e.g. the form hasn't loaded yet),
    falls back to an interactive picker listing all visible top-level windows.

.PARAMETER Width
    Initial width (px) of the preview window. Default 480.

.PARAMETER Height
    Initial height (px) of the preview window. Default 320.

.EXAMPLE
    .\Show-WindowThumbnail.ps1
    # Targets the Self KYC Form window directly.

.EXAMPLE
    .\Show-WindowThumbnail.ps1 -WindowTitle "*something else*"
    # Override to target a different window.

.NOTES
    - Requires DWM composition enabled (default on Windows 10/11).
    - WinForms requires a Single-Threaded Apartment (STA). This script detects
      the wrong apartment state (e.g. when launched via pwsh.exe, a scheduled
      task, or some shortcut configurations) and automatically relaunches
      itself correctly -- you shouldn't need to think about this.
    - On any error, this script logs details next to itself
      (Show-WindowThumbnail-error.log) and pauses with "Press Enter to close"
      instead of letting the window vanish silently -- so double-click /
      shortcut launches are diagnosable too.
    - The target window just needs to exist somewhere on the same desktop
      session (it can be on a different monitor / extended display) -- it does
      not need to be visible or in focus.
    - Close the preview window to cleanly unregister the DWM thumbnail.
#>

param(
    [string]$WindowTitle = "*Self KYC Form*",
    [int]$Width = 480,
    [int]$Height = 320
)

# --- 1. Guarantee STA apartment state (required by WinForms) ---------------
# powershell.exe defaults to STA; pwsh.exe (PowerShell 7+) defaults to MTA and
# will throw immediately on the first WinForms call. Rather than guess which
# host launched us, just check and self-relaunch correctly if needed.
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $psExe = (Get-Command powershell.exe -ErrorAction SilentlyContinue).Source
    if (-not $psExe) { $psExe = (Get-Command pwsh.exe -ErrorAction SilentlyContinue).Source }

    if ($psExe) {
        $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Sta', '-File', "`"$PSCommandPath`"")
        if ($WindowTitle) { $argList += @('-WindowTitle', "`"$WindowTitle`"") }
        $argList += @('-Width', $Width, '-Height', $Height)
        Start-Process -FilePath $psExe -ArgumentList $argList
        return
    }
    else {
        Write-Warning "Could not find powershell.exe or pwsh.exe to relaunch in STA mode. Continuing anyway -- this may fail."
    }
}

$LogPath = Join-Path (Split-Path -Parent $PSCommandPath) "Show-WindowThumbnail-error.log"

try {

    # --- 2. Load required assemblies and native DWM interop ----------------
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    # Add-Type compiles into the current session and can't redefine a type
    # once loaded -- guard against that so re-running the script in the same
    # console (after closing the preview window) doesn't error out.
    if (-not ([System.Management.Automation.PSTypeName]'DwmThumb').Type) {
        Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

// Enumerates ALL visible top-level windows on the desktop, regardless of how
// many windows a single process owns. Get-Process's MainWindowHandle only
// reports one window per process, which misses secondary browser windows
// (e.g. a kiosk window on a second monitor owned by an already-running
// browser process) -- this is the fix for that.
public class WinInfo {
    public IntPtr Handle;
    public string Title;
    public int ProcessId;
}

public static class WinEnum {
    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int GetWindowTextLength(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);

    [DllImport("user32.dll")]
    private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    private const uint GA_ROOT = 2;
    private const int GWL_EXSTYLE = -20;
    private const int WS_EX_TOOLWINDOW = 0x00000080;

    public static List<WinInfo> ListTopLevelWindows() {
        var results = new List<WinInfo>();
        EnumWindows((hWnd, lParam) => {
            if (!IsWindowVisible(hWnd)) return true;
            // Skip owned popups/tooltips -- only keep true top-level (root) windows
            if (GetAncestor(hWnd, GA_ROOT) != hWnd) return true;
            // Skip tool windows (floating toolbars etc, not real app windows)
            int exStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
            if ((exStyle & WS_EX_TOOLWINDOW) != 0) return true;

            int len = GetWindowTextLength(hWnd);
            if (len == 0) return true;
            var sb = new StringBuilder(len + 1);
            GetWindowText(hWnd, sb, sb.Capacity);
            string title = sb.ToString();
            if (string.IsNullOrWhiteSpace(title)) return true;

            uint pid;
            GetWindowThreadProcessId(hWnd, out pid);

            results.Add(new WinInfo { Handle = hWnd, Title = title, ProcessId = (int)pid });
            return true;
        }, IntPtr.Zero);
        return results;
    }
}

public static class DwmThumb {
    [DllImport("dwmapi.dll")]
    public static extern int DwmRegisterThumbnail(IntPtr dest, IntPtr src, out IntPtr thumb);

    [DllImport("dwmapi.dll")]
    public static extern int DwmUnregisterThumbnail(IntPtr thumb);

    [DllImport("dwmapi.dll")]
    public static extern int DwmUpdateThumbnailProperties(IntPtr thumb, ref DWM_THUMBNAIL_PROPERTIES props);

    public const int DWM_TNP_RECTDESTINATION = 0x1;
    public const int DWM_TNP_OPACITY         = 0x4;
    public const int DWM_TNP_VISIBLE         = 0x8;

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    public struct DWM_THUMBNAIL_PROPERTIES {
        public int dwFlags;
        public RECT rcDestination;
        public RECT rcSource;
        public byte opacity;
        [MarshalAs(UnmanagedType.Bool)] public bool fVisible;
        [MarshalAs(UnmanagedType.Bool)] public bool fSourceClientAreaOnly;
    }
}
"@
    }

    # --- 3. Find target window ------------------------------------------------
    # Uses EnumWindows (all top-level windows on the desktop) rather than
    # Get-Process/MainWindowHandle (one window per process) so windows on a
    # second monitor -- and secondary windows of an already-running browser --
    # are actually visible to the picker.
    function Get-CandidateWindows {
        [WinEnum]::ListTopLevelWindows() | ForEach-Object {
            $procName = try { (Get-Process -Id $_.ProcessId -ErrorAction Stop).ProcessName } catch { "?" }
            [PSCustomObject]@{
                Title       = $_.Title
                Handle      = $_.Handle
                ProcessId   = $_.ProcessId
                ProcessName = $procName
            }
        }
    }

    $target = $null
    if ($WindowTitle) {
        $target = Get-CandidateWindows | Where-Object { $_.Title -like $WindowTitle } | Select-Object -First 1
        if (-not $target) {
            Write-Warning "No window matched '$WindowTitle'. Falling back to picker."
        }
    }

    if (-not $target) {
        $candidates = @(Get-CandidateWindows)
        if ($candidates.Count -eq 0) {
            throw "No visible top-level windows found to replicate."
        }
        Write-Host "Select a window to replicate:"
        for ($i = 0; $i -lt $candidates.Count; $i++) {
            Write-Host "  [$i] $($candidates[$i].Title)  ($($candidates[$i].ProcessName))"
        }
        $sel = Read-Host "Enter number"
        if ($sel -notmatch '^\d+$' -or [int]$sel -ge $candidates.Count) {
            throw "Invalid selection: '$sel'"
        }
        $target = $candidates[[int]$sel]
    }

    $srcHandle = $target.Handle

    # --- 4. Build the always-on-top host window ------------------------------
    $form = New-Object System.Windows.Forms.Form
    $form.Text            = "Live: $($target.Title)"
    $form.FormBorderStyle = 'Sizable'
    $form.TopMost         = $true
    $form.StartPosition   = 'Manual'
    $form.Location        = New-Object System.Drawing.Point(60, 60)
    $form.Size            = New-Object System.Drawing.Size($Width, $Height)
    $form.BackColor       = [System.Drawing.Color]::Black

    $script:thumb = [IntPtr]::Zero

    function Update-ThumbRect {
        if ($script:thumb -eq [IntPtr]::Zero) { return }
        $props = New-Object 'DwmThumb+DWM_THUMBNAIL_PROPERTIES'
        $props.dwFlags = [DwmThumb]::DWM_TNP_RECTDESTINATION -bor [DwmThumb]::DWM_TNP_VISIBLE -bor [DwmThumb]::DWM_TNP_OPACITY
        $rect = New-Object 'DwmThumb+RECT'
        $rect.Left = 0; $rect.Top = 0
        $rect.Right = $form.ClientSize.Width
        $rect.Bottom = $form.ClientSize.Height
        $props.rcDestination = $rect
        $props.opacity = 255
        $props.fVisible = $true
        [DwmThumb]::DwmUpdateThumbnailProperties($script:thumb, [ref]$props) | Out-Null
    }

    $form.Add_Shown({
        $hr = [DwmThumb]::DwmRegisterThumbnail($form.Handle, $srcHandle, [ref]$script:thumb)
        if ($hr -ne 0) {
            [System.Windows.Forms.MessageBox]::Show("DwmRegisterThumbnail failed (HRESULT 0x$($hr.ToString('X'))). Is Desktop Composition (DWM) running?", "Error") | Out-Null
            $form.Close()
            return
        }
        Update-ThumbRect
    })
    $form.Add_Resize({ Update-ThumbRect })
    $form.Add_FormClosing({
        if ($script:thumb -ne [IntPtr]::Zero) {
            [DwmThumb]::DwmUnregisterThumbnail($script:thumb) | Out-Null
        }
    })

    [System.Windows.Forms.Application]::Run($form)

}
catch {
    $errText = "$(Get-Date -Format s)  $($_.Exception.GetType().FullName): $($_.Exception.Message)`r`n$($_.ScriptStackTrace)`r`n"
    $errText | Out-File -FilePath $LogPath -Append -Encoding utf8

    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Details logged to: $LogPath" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press Enter to close this window"
}
